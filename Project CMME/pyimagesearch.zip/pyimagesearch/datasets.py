# import the necessary packages
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np
import glob
import cv2
import os
from skimage import io
import matplotlib.pyplot as plt



def load_RVE_labels_displ(inputPath,L):
	# initialize the list of column names in the CSV file and then
	# load it using Pandas
	l=str(L[0])
	cols = ["E1_Uniform_Strain_BCs","E2_Uniform_Strain_BCs","n12_Uniform_Strain_BCs","n21_Uniform_Strain_BCs","G_Uniform_Strain_BCs"]
	df = pd.read_csv(inputPath+'/Labels-displacement-'+l+'x'+l+'.csv', sep=",", header=None, names=cols)
	# return the data frame
	return df




def load_RVE_original_images(inputPath,L,res,N):
	l=str(L[0])
	os.chdir(inputPath+'/Dataset Original '+l+'x'+l )
	
	images = []
	for j in range(0,len(L)):
		str1='./rve-'+str(L[j])+'x'+str(L[j])+'-reg2-'
		for i in range(1,N+1):			
			try:
				image=cv2.imread('rve-'+str(L[j])+'x'+str(L[j])+'-reg2-'+str(i)+'-1.jpg', cv2.COLOR_BGR2GRAY)
				image = cv2.resize(image, (res,res))
				images.append(image)
			except Exception as e:
				pass
				
				
		
	return np.array(images) # return our set of images





